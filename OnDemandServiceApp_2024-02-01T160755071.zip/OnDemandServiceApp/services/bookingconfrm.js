import { baseUrl } from "./supabase.js";
import AsyncStorage from '@react-native-async-storage/async-storage';

export async function bookingConfirm({ saloonId, selectedDate, selectedTime, mainServiceId, subServiceId}) {
    console.log(saloonId, selectedDate, selectedTime, mainServiceId, subServiceId)
    try {
        // Fetch user data from AsyncStorage
        const userDataString = await AsyncStorage.getItem('userData');
        const userData = JSON.parse(userDataString);
        const userId = userData?.userData?._id;
        const authToken = await AsyncStorage.getItem('AuthToken');
        
        // Construct the booking payload
        const bookingPayload = {
            Beautician: saloonId, // Dummy beautician ID
            User: userId, // Use the user ID fetched from AsyncStorage
            Promotion: '', // Dummy promotion ID
            Service: [
                {
                    service: "658c79008c13f27fc7d9e315",
                    Type: [
                        {
                            TypeID: "658c79008c13f27fc7d9e316" // Dummy type ID
                        }
                    ]
                }
            ],
            Payment: {
                Type: "Online",
                OnlinePayment: "65ba0b2f48eebf5d107259c7" // Dummy online payment ID
            },
            BookingTime: {
                Date: selectedDate,
                Month: "January", // This might need to be dynamically calculated
                Time: selectedTime
            },
            TotalAmount: "2500", // Dummy total amount
            Status: "Pending",
            BookingAddress: {
                Address: "123 Main St",
                City: "Cityville",
                lat: "12.345",
                lan: "67.890"
            }
        };

        // Send the booking payload to the server
        const response = await fetch(`${baseUrl}/api/userAuth/createBooking`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify(bookingPayload),
        });

        if (!response.ok) {
            throw new Error('Failed to create booking');
        }

        const data = await response.json();

        return data;
    } catch (error) {
        console.error('Error creating booking:', error);
        throw error;
    }
}
