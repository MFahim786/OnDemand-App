import React, { useState, useEffect } from 'react';
import { View, Text, Image, Platform ,TextInput ,TouchableOpacity,ActivityIndicator} from 'react-native';
import ScreenWrapper from '../../components/ScreenWrapper';
import { colors } from '../../theme';
import { responsiveHeight as Rh, responsiveScreenWidth as Rw, responsiveScreenFontSize as fo } from 'react-native-responsive-dimensions';
import { useWindowDimensions } from 'react-native';
import { useProductContext } from '../../contexprovider/ProduxtContext'; // Import the context hook
import { useRoute } from '@react-navigation/native';
import BookingButtons from '../../components/bookingButton';
import { bookingConfirm } from '../../services/bookingconfrm';

const RecptBooking = () => {
  const route = useRoute();
  const { products } = useProductContext(); 
  const [loading, setLoading] = useState(false);
  const { saloonId,selectedDate , selectedTime } = route.params;
  
  console.log(saloonId,selectedDate , selectedTime)
  const handleBooking = async (mainServiceId, subServiceId) => {
    console.log("pressed with mainServiceId:", mainServiceId, "and subServiceId:", subServiceId);
   
    try {
      // Pass mainServiceId and subServiceId to bookingConfirm function
      await bookingConfirm({saloonId, selectedDate, selectedTime, mainServiceId, subServiceId});
    } catch (error) {
      console.error('Error confirming booking:', error);
    }
  }

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }  

  const renderServiceItem = (title, price, mainServiceId, subServiceId) => (
    <TouchableOpacity onPress={() => handleBooking(mainServiceId, subServiceId)}>
      <View style={{ backgroundColor: colors.ServiceProvider_buttonBackground, height: Rh(5), width: Rh(38), marginTop: Rh(0.1) }}>
          <Text style={{ fontSize: fo(2), marginTop: Rw(2.5), color: colors.background, marginLeft: Rw(6) }}>{title}</Text>
          <View><Text style={{ fontSize: fo(2), marginTop: Rw(-5.5), color: colors.background, marginLeft: Rw(60) }}>Pkr {price}</Text></View>
      </View>
    </TouchableOpacity>
  );

  const useStyles = () => {
    const { width, height } = useWindowDimensions();
    // Add your style calculations here if needed
  }

  const styles = useStyles();

  return (
    <ScreenWrapper>
      <View>
        <Text style={{ fontFamily: colors.fontfaimly_heding, textAlign: 'center', fontSize: fo(3), fontWeight: 'bold', color: colors.heading, marginTop: Rh(4) }}>Receipt</Text>
      </View>
      {/* ServiceProvider Section */}
      <View style={{ flexDirection: 'row' }}>
        {[{ image: require('../../assets/popularServiceProvider/Bacground.png') },
        { image: require('../../assets/Icons/Vector1.png') },
        { image: require('../../assets/popularServiceProvider/ayeshawomen.png') },
        ].map((item, index) => (
          <View key={index} style={{ marginTop: index === 0 ? Rh(4) : index === 1 ? Rh(5) : Rh(1), width: index === 1 ? 0 : Rw(7), marginLeft: item.marginLeft }}>
            <Image source={item.image} style={{ ...item.style }} />
          </View>
        ))}

        <View style={{ flexDirection: 'row', marginTop: Rh(4), borderStyle: 'dashed', borderColor: colors.font1, borderWidth: Rw(0.4), height: Rh(10), width: Rw(60), marginHorizontal: Rw(21), borderTopRightRadius: Rw(5), borderBottomRightRadius: Rw(5), overflow: 'hidden' }}>
          <View>
            <Text style={{ fontSize: fo(2), fontWeight: 'bold', marginTop: Rw(1), color: colors.font1, marginLeft: Rw(7) }}>Serenity Salon</Text>
            <Text style={{ fontSize: fo(2), fontWeight: 'bold', marginTop: Rw(0.1), color: colors.heading, marginLeft: Rw(8) }}>56478965</Text>
            <Image source={require('../../assets/Icons/star.png')} style={{ marginTop: Rw(0.2), marginLeft: Rw(4.3), width: Rw(4.5) }} />
            <Text style={{ fontSize: fo(1.7), fontWeight: 'bold', marginTop: Rw(-3.7), color: colors.font1, marginLeft: Rw(9) }}>4.9</Text>
            <Text style={{ fontSize: fo(1.7), fontWeight: 'bold', marginTop: Rw(-5), color: colors.heading, marginLeft: Rw(14.5) }}>(27)</Text>
          </View>
        </View>
      </View>

      {/* Date and Time Section */}
      {[{ title: 'Date: Fri, 13 May 2023' }, { title: 'Time: 11:00 AM' }].map((item, index) => (
        <View key={index} style={{ elevation: Platform.OS === 'android' ? 5 : undefined, marginLeft: Rw(11), backgroundColor: colors.ServiceProvider_buttonBackground, height: Rh(5), width: Rh(36), borderRadius: Rw(1), marginTop: index === 1 ? Rh(2) : Rh(0) }}>
          <Text style={{ borderColor: colors.background, borderWidth: Rw(0.5), fontSize: fo(2), marginTop: Rw(1.9), color: colors.font1, marginLeft: Rw(2), marginRight: Rw(2), textAlign: 'center' }}>{item.title}</Text>
        </View>
      ))}

      {/* Pricing Section */}
      <View style={{ marginTop: Rh(2), marginLeft: Rw(7), width: Rw(85), height: Rh(37), borderWidth: Rw(2), borderColor: colors.background }}>
        <View style={{ backgroundColor: colors.headerbackground, height: Rh(5), width: Rh(38) }}>
          <Text style={{ fontSize: fo(2), marginTop: Rw(2.5), color: colors.background, marginLeft: Rw(6) }}>Pricing</Text>
        </View>
        <Text>
          {products?.map((item, index) => (
            <React.Fragment key={index}>
              {/* Log subServices within each product */}
              {item?.subServices?.map((subService, subIndex) => (
                <React.Fragment key={subIndex}>
                  {renderServiceItem(subService?.name, subService?.realPrice, item._id, subService._id)}
                  {console.log(subService?.name, subService?.realPrice)}
                </React.Fragment>
              ))}
            </React.Fragment>
          ))}
        </Text>
      </View>

      {/* Total Time, Subtotal, Coupon Discount, and Total Section */}
      <View style={{ flexDirection: "row", marginTop: Rh(1.5) }}>
        <Text style={{ marginLeft: Rw(9), fontFamily: colors.fontfaimly_heding, color: colors.heading }}>Total Time:</Text>
        <Text style={{ marginLeft: Rw(50), fontWeight: 'bold', fontFamily: colors.fontfaimly_text, color: colors.font1 }}>20 Minutes</Text>
      </View>
      {/* Cupon input field */}
      <View>
        <View style={{ marginTop: Rh(2), paddingHorizontal: Rw(7) }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', borderRadius: 20, borderWidth: 1, borderColor: colors.font1, overflow: 'hidden' }}>
            {/* Red dot */}
            <View style={{ backgroundColor: 'red', width: 10, height: 10, borderRadius: 5, marginLeft: 10 }} />
            
            {/* Coupon input field */}
            <TextInput
              style={{ flex: 1, paddingVertical: 10, paddingHorizontal: 15, fontSize: fo(2), color: colors.font1 }}
              placeholder="Enter coupon code"
              placeholderTextColor={colors.font1}
              // Add onChangeText prop to update the coupon state
            />
            
            {/* Apply button */}
            <TouchableOpacity
              style={{ backgroundColor: colors.ServiceProvider_buttonBackground, paddingHorizontal: 20, paddingVertical: 10 }}
            >
              <Text style={{ fontSize: fo(2), color: colors.background }}>Apply</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      {/* Confirm Button */}
      <View style={{ marginTop: Rh(11), fontFamily: colors.fontfaimly_heding }}>
        <BookingButtons backgroundColor={colors.ServiceProvider_buttonBackground} titlenext={'Book Now' } pressnext={()=>handleBooking()} />
      </View>
    </ScreenWrapper>
  );
};

export default RecptBooking;
