module.exports = {
project:{
ios:{},
android:{},
},
assests:["assets/fonts"]
}