export const PopularItems = [
    {
      id: 1,
      img:require("./Bacground.png"),
     saloname: 'Santrey Saloon',
      Phone:'657-433-675',
      review:'27',
      rating:'4.5',

    },
    {
      id: 2,
      img:require("./Bacground.png"),
      saloname: 'Santrey Saloon',
      Phone:'657 433 675',
      review:'27',
      rating:'4.5',
    },
    {
      id: 3,
      img:require("./Bacground.png"),
      saloname: 'Santrey Saloon',
      Phone:'657 433 675',
      review:'27',
      rating:'4.5',
    },
    {
      id: 4,
      img:require("./Bacground.png"),
      saloname: 'Santrey Saloon',
      Phone:'657 433 675',
      review:'27',
      rating:'4.5',
    },
    {
      id: 5,
      img:require("./Bacground.png"),
      saloname: 'Santrey Saloon',
      Phone:'657 433 675',
      review:'27',
      rating:'4.5',
    }
  ];