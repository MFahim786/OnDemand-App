export const catitems = [
    {
      id: 1,
      img:require("./1.png"),
      categorey: 'HairCut',

    },
    {
      id: 2,
      categorey: 'HairCut',
      img:require("./2.png"),
    },
    {
      id: 3,
      categorey: 'HairCut',
      img:require("./3.png"),
    },
    {
      id: 4,
      categorey: 'HairCut',
      img:require("./4.png"),
    },
    {
      id: 5,
      categorey: 'HairCut',
      img:require("./5.png"),
    }
  ];