export const NearbyItems = [
    {
      id: 1,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      saloname: 'Santrey Saloon',
      Pjone:'657 433 675',
      review:'27',
      rating:'4.5',

    },
    {
      id: 2,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 3,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 4,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 5,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    }
  ];