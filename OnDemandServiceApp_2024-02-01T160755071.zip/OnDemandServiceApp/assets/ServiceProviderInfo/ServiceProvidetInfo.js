export const serviceProviderInfo = [
    {
      id: 1,
      img:require("./1.png"),
     saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan international,Language',
      distance:'2km',
      rating:'4.5',
      noofRating:27,
      phonenumber:'92-3063847-4874',
      availabilityStatus:'Available'
    },
    {
      id: 2,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 3,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 4,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    },
    {
      id: 5,
      img:require("./1.png"),
      saloname: 'Santrey Saloon',
      Address:'Ali town lahore punjab pakistan',
      distance:'2km',
      rating:'4.5',
    }
  ];
  export const services = [
    {
      serviceName: 'Haircut',
      details: [
        {
          style: 'Classic Cut',
          price: 20,
        },
        {
          style: 'Fade',
          price: 25,
        },
        {
          style: 'Trim',
          price: 15,
        },
      ],
    },
    {
      serviceName: 'Manicure',
      details: [
        {
          type: 'Regular',
          price: 10,
        },
        {
          type: 'Gel',
          price: 20,
        },
      ],
    },
    {
      serviceName: 'Pedicure',
      details: [
        {
          type: 'Basic',
          price: 15,
        },
        {
          type: 'Spa',
          price: 25,
        },
      ],
    },
  ];
  