import React from 'react';
import { Text, View } from 'react-native';
import AppNavigation from './AppNavigation/Appnavigation';
import ServiceProvider from './Src/ServiceProviderInfo/Index';
function App() {
  return (
    <AppNavigation />
  );
}

export default App;
